<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>MEN_CHANGE_BACKGROUND</source>
      <translation>Change Background...</translation>
    </message>
    <message>
      <source>MNU_PAN_VIEW</source>
      <translation>Panning</translation>
    </message>
    <message>
      <source>DSC_PAN_VIEW</source>
      <translation>Panning the view</translation>
    </message>
    <message>
      <source>MNU_RESET_VIEW</source>
      <translation>Reset</translation>
    </message>
    <message>
      <source>DSC_RESET_VIEW</source>
      <translation>Reset View Point</translation>
    </message>
    <message>
      <source>LBL_TOOLBAR_LABEL</source>
      <translation>View Operations</translation>
    </message>
  </context>
  <context>
    <name>QxScene_ViewManager</name>
    <message>
      <source>QXSCENE_VIEW_TITLE</source>
      <translation>QGraphics scene:%M - viewer:%V</translation>
    </message>
  </context>
</TS>
