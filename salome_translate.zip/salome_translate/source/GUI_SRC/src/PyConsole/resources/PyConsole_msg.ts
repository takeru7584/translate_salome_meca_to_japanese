<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>PyConsole_Console</name>
    <message>
      <location filename="../PyConsole_Console.cxx" line="216"/>
      <source>EDIT_COPY_CMD</source>
      <translation>&amp;Copy</translation>
    </message>
    <message>
      <location filename="../PyConsole_Console.cxx" line="221"/>
      <source>EDIT_PASTE_CMD</source>
      <translation>&amp;Paste</translation>
    </message>
    <message>
      <location filename="../PyConsole_Console.cxx" line="226"/>
      <source>EDIT_CLEAR_CMD</source>
      <translation>Clea&amp;r</translation>
    </message>
    <message>
      <location filename="../PyConsole_Console.cxx" line="231"/>
      <source>EDIT_SELECTALL_CMD</source>
      <translation>Select &amp;All</translation>
    </message>
    <message>
      <source>EDIT_DUMPCOMMANDS_CMD</source>
      <translation>D&amp;ump commands</translation>
    </message>
  </context>
  <context>
    <name>PyConsole_Editor</name>
    <message>
      <source>TOT_DUMP_PYCOMMANDS</source>
      <translation>Dump commands</translation>
    </message>
    <message>
      <source>PYTHON_FILES_FILTER</source>
      <translation>PYTHON Files (*.py)</translation>
    </message>
  </context>
</TS>
