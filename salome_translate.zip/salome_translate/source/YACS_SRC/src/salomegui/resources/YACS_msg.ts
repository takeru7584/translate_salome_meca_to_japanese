<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>Yacsgui</name>
    <message>
      <source>PREF_TAB_GENERAL</source>
      <translation>General</translation>
    </message>
    <message>
      <source>PREF_GROUP_COMPONENT</source>
      <translation>Component</translation>
    </message>
    <message>
      <source>PREF_TAB_STATE</source>
      <translation>Node states</translation>
    </message>
    <message>
      <source>PREF_GROUP_EDIT</source>
      <translation>Edit states</translation>
    </message>
    <message>
      <source>PREF_GROUP_RUN</source>
      <translation>Run states</translation>
    </message>
    <message>
      <source>PREF_TAB_NODE</source>
      <translation>Nodes</translation>
    </message>
    <message>
      <source>PREF_GROUP_SCENE</source>
      <translation>Scene</translation>
    </message>
    <message>
      <source>PREF_GROUP_BLOC</source>
      <translation>Block</translation>
    </message>
    <message>
      <source>PREF_GROUP_NODE</source>
      <translation>Node</translation>
    </message>
    <message>
      <source>PREF_GROUP_HEADER</source>
      <translation>Header</translation>
    </message>
    <message>
      <source>PREF_GROUP_CONTROL</source>
      <translation>Control port</translation>
    </message>
    <message>
      <source>PREF_GROUP_PORT</source>
      <translation>Dataflow Port</translation>
    </message>
    <message>
      <source>PREF_GROUP_DRAG</source>
      <translation>Dragging</translation>
    </message>
    <message>
      <source>PREF_GROUP_GENERAL</source>
      <translation>General</translation>
    </message>
    <message>
      <source>COMPONENT_INSTANCE_NEW</source>
      <translation>Create a component instance for each new service node</translation>
    </message>
    <message>
      <source>ERROR</source>
      <translation>ERROR</translation>
    </message>
    <message>
      <source>YACS_PLUGINS</source>
      <translation>Plugins</translation>
    </message>
  </context>
</TS>
