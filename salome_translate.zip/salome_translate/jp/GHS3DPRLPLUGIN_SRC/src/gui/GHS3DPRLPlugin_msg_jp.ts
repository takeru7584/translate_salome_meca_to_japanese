<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>GHS3DPRL_3D_HYPOTHESIS</source>
      <translation>GHS3DPRL 3 D</translation>
    </message>
    <message>
      <source>GHS3DPRL_3D_TITLE</source>
      <translation>仮説構築</translation>
    </message>
    <message>
      <source>GHS3DPRL_KeepFiles</source>
      <translation>ファイルを保存します。</translation>
    </message>
    <message>
      <source>GHS3DPRL_Background</source>
      <translation>バック グラウンドで枕</translation>
    </message>
    <message>
      <source>GHS3DPRL_ToMeshHoles</source>
      <translation>メッシュに穴します。</translation>
    </message>
    <message>
      <source>GHS3DPRL_MEDName</source>
      <translation>音楽配信マック ＆ 名</translation>
    </message>
    <message>
      <source>GHS3DPRL_NbPart</source>
      <translation>Nb パーティション</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_KeepFiles</source>
      <translation>中間代謝産物枕ファイル (.faces、.points、.msg、.noboite...）</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_Background</source>
      <translation>弁当枕バック グラウンド （の大きなメッシュ、長い時間を...)</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_ToMeshHoles</source>
      <translation>花被片より穴をメッシュします。</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_MEDName</source>
      <translation>決勝戦の一般的なパスと名前の出力ファイル (.med)</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_Name</source>
      <translation>応用仮設の名前</translation>
    </message>
    <message>
      <source>GHS3DPRL_WhatsThis_NbPart</source>
      <translation>最初のラップのパーティションの数</translation>
    </message>
  </context>
</TS>
