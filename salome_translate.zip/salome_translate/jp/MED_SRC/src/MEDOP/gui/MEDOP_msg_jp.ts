<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>TOOL_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>TLT_MY_NEW_ITEM</source>
      <translation>私メニュー項目</translation>
    </message>
    <message>
      <source>TLT_LOAD_DXF</source>
      <translation>DXF ファイルの読み込み</translation>
    </message>
    <message>
      <source>MEN_LOAD_DXF</source>
      <translation>DXF ファイルの読み込み</translation>
    </message>
    <message>
      <source>STS_LOAD_DXF</source>
      <translation>DXF ファイルの読み込み</translation>
    </message>
    <message>
      <source>TLT_GET_BANNER</source>
      <translation>XMED のバナーを取得します。</translation>
    </message>
    <message>
      <source>STS_MY_NEW_ITEM</source>
      <translation>私のメニューを呼び出す</translation>
    </message>
    <message>
      <source>MEN_FILE_XMED</source>
      <translation>Xmed</translation>
    </message>
    <message>
      <source>MEN_GET_BANNER</source>
      <translation>バナーを取得します。</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>&amp; ファイル</translation>
    </message>
    <message>
      <source>STS_GET_BANNER</source>
      <translation>XMED のバナーを取得します。</translation>
    </message>
    <message>
      <source>TLT_BUILDER1</source>
      <translation>基本ベクトル Vx, Vy, Vz を作成します。</translation>
    </message>
    <message>
      <source>TLT_BUILDER2</source>
      <translation>接続エッジ (円弧とライン) を作成します。</translation>
    </message>
    <message>
      <source>TLT_BUILDER3</source>
      <translation>Python スクリプトをロードします。</translation>
    </message>
    <message>
      <source>STS_BUILDER1</source>
      <translation>基本ベクトル Vx, Vy, Vz を作成します。</translation>
    </message>
    <message>
      <source>STS_BUILDER2</source>
      <translation>接続エッジ (円弧とライン) を作成します。</translation>
    </message>
    <message>
      <source>STS_BUILDER3</source>
      <translation>Python スクリプトをロードします。</translation>
    </message>
    <message>
      <source>MEN_BUILDER1</source>
      <translation>基本ベクトル Vx, Vy, Vz を作成します。</translation>
    </message>
    <message>
      <source>MEN_BUILDER2</source>
      <translation>接続エッジ (円弧とライン) を作成します。</translation>
    </message>
    <message>
      <source>MEN_BUILDER3</source>
      <translation>Python スクリプトをロードします。</translation>
    </message>
    <message>
      <source>MEN_XMED</source>
      <translation>XMED</translation>
    </message>
    <message>
      <source>MEN_MY_NEW_ITEM</source>
      <translation>私メニュー項目</translation>
    </message>
  </context>
  <context>
    <name>XMEDGUI_maquette</name>
    <message>
      <source>BUT_OK</source>
      <translation>わかりました</translation>
    </message>
    <message>
      <source>QUE_XMED_LABEL</source>
      <translation>名前のインポート</translation>
    </message>
    <message>
      <source>QUE_XMED_NAME</source>
      <translation>あなたの名前を入力してください、</translation>
    </message>
    <message>
      <source>INF_XMED_BANNER</source>
      <translation>XMED 情報</translation>
    </message>
    <message>
      <source>INF_XMED_MENU</source>
      <translation>これはテストです。</translation>
    </message>
  </context>
</TS>
