<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>MEN_CHANGE_BACKGROUND</source>
      <translation>背景の変更.</translation>
    </message>
    <message>
      <source>MNU_PAN_VIEW</source>
      <translation>パン</translation>
    </message>
    <message>
      <source>DSC_PAN_VIEW</source>
      <translation>パン表示]</translation>
    </message>
    <message>
      <source>MNU_RESET_VIEW</source>
      <translation>リセット</translation>
    </message>
    <message>
      <source>DSC_RESET_VIEW</source>
      <translation>リセット ビュー ポイント</translation>
    </message>
    <message>
      <source>LBL_TOOLBAR_LABEL</source>
      <translation>[操作の表示</translation>
    </message>
  </context>
</TS>
