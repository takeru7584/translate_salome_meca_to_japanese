<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>ERROR_TLT</source>
      <translation>エラー</translation>
    </message>
    <message>
      <source>ERROR_ACTIVATE_MODULE_MSG</source>
      <translation>モジュール%1 をアクティブにできませんでした。</translation>
    </message>
    <message>
      <source>MODULE_ROOT_OBJECT_TOOLTIP</source>
      <translation>%1 モジュール ルート オブジェクト</translation>
    </message>
  </context>
</TS>
