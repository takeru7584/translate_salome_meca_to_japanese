<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>APP_OK</source>
      <translation>わかりました</translation>
    </message>
    <message>
      <source>APP_ERROR</source>
      <translation>エラー</translation>
    </message>
    <message>
      <source>APP_UNK_EXCEPTION</source>
      <translation>不明な例外</translation>
    </message>
  </context>
</TS>
