<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>LogWindow</name>
    <message>
      <location filename="../LogWindow.cxx" line="293"/>
      <source>EDIT_COPY_CMD</source>
      <translation>&amp; コピー</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="298"/>
      <source>EDIT_CLEAR_CMD</source>
      <translation>クレア &amp; r</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="303"/>
      <source>EDIT_SELECTALL_CMD</source>
      <translation>&amp; すべてを選択します</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="308"/>
      <source>EDIT_SAVETOFILE_CMD</source>
      <translation>&amp; ログ ファイルに保存.</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_ERROR</source>
      <translation>エラー</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>ERR_CANT_SAVE_FILE</source>
      <translation>ファイルを保存できません。</translation>
    </message>
    <message>
      <location filename="../LogWindow.cxx" line="368"/>
      <source>BUT_OK</source>
      <translation>&amp; [OK]</translation>
    </message>
  </context>
</TS>
