<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
  <context>
    <name>@default</name>
    <message>
      <source>TOP_CLEAR_ALL</source>
      <translation>すべてクリア</translation>
    </message>
    <message>
      <source>STB_CLEAR_ALL</source>
      <translation>すべてのテキスト行を削除します。</translation>
    </message>
    <message>
      <source>STB_SAVE_FILE</source>
      <translation>テキスト ファイルを保存します。</translation>
    </message>
    <message>
      <source>TOP_SAVE_FILE</source>
      <translation>テキスト ファイルを保存します。</translation>
    </message>
    <message>
      <source>MEN_LIGHT</source>
      <translation>光</translation>
    </message>
    <message>
      <source>MEN_LOAD_FILE</source>
      <translation>テキスト ファイルの読み込み</translation>
    </message>
    <message>
      <source>WRN_UNKNOWN_COMMAND</source>
      <translation>コマンドを認識できません。</translation>
    </message>
    <message>
      <source>BUT_OK</source>
      <translation>&amp; [OK]</translation>
    </message>
    <message>
      <source>WRN_ADD_FAILED</source>
      <translation>行を挿入することはできません ！</translation>
    </message>
    <message>
      <source>STB_DISPLAY_LINE</source>
      <translation>選択した行を表示します。</translation>
    </message>
    <message>
      <source>TOP_DISPLAY_LINE</source>
      <translation>行を表示します。</translation>
    </message>
    <message>
      <source>MEN_DISPLAY_LINE</source>
      <translation>選択した行を表示します。</translation>
    </message>
    <message>
      <source>STB_ERASE_LINE</source>
      <translation>選択した行を消去します。</translation>
    </message>
    <message>
      <source>TOP_ERASE_LINE</source>
      <translation>線を消去します。</translation>
    </message>
    <message>
      <source>MEN_ERASE_LINE</source>
      <translation>選択した行を消去します。</translation>
    </message>
    <message>
      <source>STB_EDIT_LINE</source>
      <translation>選択した行を編集します。</translation>
    </message>
    <message>
      <source>WRN_EDIT_FAILED</source>
      <translation>行を編集することはできません ！</translation>
    </message>
    <message>
      <source>WRN_DUMP_FAILED</source>
      <translation>ダンプ ファイルが失敗しました。</translation>
    </message>
    <message>
      <source>WRN_LOAD_FAILED</source>
      <translation>ファイルの読み込みに失敗しましたです。</translation>
    </message>
    <message>
      <source>TOP_EDIT_LINE</source>
      <translation>行を編集します。</translation>
    </message>
    <message>
      <source>MEN_CLEAR_ALL</source>
      <translation>すべてクリア</translation>
    </message>
    <message>
      <source>MEN_FILE</source>
      <translation>&amp; ファイル</translation>
    </message>
    <message>
      <source>LIGHT_ROOT_TOOLTIP</source>
      <translation>ライト モジュール ルート オブジェクト</translation>
    </message>
    <message>
      <source>LIGHT_LIGHT</source>
      <translation>光</translation>
    </message>
    <message>
      <source>MEN_SAVE_FILE</source>
      <translation>テキスト ファイルを保存します。</translation>
    </message>
    <message>
      <source>WRN_WARNING</source>
      <translation>警告 ！</translation>
    </message>
    <message>
      <source>WRN_DELETE_FAILED</source>
      <translation>行を削除できません。</translation>
    </message>
    <message>
      <source>WRN_SELECT_LINE</source>
      <translation>間違った選択 ！</translation>
    </message>
    <message>
      <source>TOP_LOAD_FILE</source>
      <translation>テキスト ファイルの読み込み</translation>
    </message>
    <message>
      <source>TOP_ADD_LINE</source>
      <translation>行を追加します</translation>
    </message>
    <message>
      <source>MEN_DEL_LINE</source>
      <translation>行を削除します。</translation>
    </message>
    <message>
      <source>STB_LOAD_FILE</source>
      <translation>テキスト ファイルの読み込み</translation>
    </message>
    <message>
      <source>STB_ADD_LINE</source>
      <translation>選択した 1 つ前に新しい行を挿入します。</translation>
    </message>
    <message>
      <source>LIGHT_PARAGRAPH</source>
      <translation>段落</translation>
    </message>
    <message>
      <source>TOP_DEL_LINE</source>
      <translation>行を削除します。</translation>
    </message>
    <message>
      <source>MEN_ADD_LINE</source>
      <translation>新しいテキスト行を挿入します。</translation>
    </message>
    <message>
      <source>LIGHT_LINE</source>
      <translation>ライン</translation>
    </message>
    <message>
      <source>STB_DEL_LINE</source>
      <translation>選択した行を削除します。</translation>
    </message>
    <message>
      <source>MEN_EDIT_LINE</source>
      <translation>選択した行を編集します。</translation>
    </message>
    <message>
      <source>MEN_SHOW_TRACE</source>
      <translation>トレースを表示する.</translation>
    </message>
    <message>
      <source>TOP_SHOW_TRACE</source>
      <translation>トレースを表示します。</translation>
    </message>
    <message>
      <source>STB_SHOW_TRACE</source>
      <translation>トレースを表示します。</translation>
    </message>
  </context>
  <context>
    <name>PVGUI_ViewManager</name>
    <message>
      <source>PARAVIEW_VIEW_TITLE</source>
      <translation>ParaView シーン:%M - ビューアー:%V</translation>
    </message>
  </context>
  <context>
    <name>PVGUI_Module</name>
    <message>
      <source>TTL_PIPELINE_BROWSER</source>
      <translation>パイプラインのブラウザー</translation>
    </message>
    <message>
      <source>TTL_OBJECT_INSPECTOR</source>
      <translation>プロパティ</translation>
    </message>
    <message>
      <source>TTL_DISPLAY</source>
      <translation>表示</translation>
    </message>
    <message>
      <source>TTL_INFORMATION</source>
      <translation>情報</translation>
    </message>
    <message>
      <source>TTL_STATISTICS_VIEW</source>
      <translation>統計ビュー</translation>
    </message>
    <message>
      <source>TTL_ANIMATION_INSPECTOR</source>
      <translation>アニメーションの検査官</translation>
    </message>
    <message>
      <source>TTL_LOOKMARK_BROWSER</source>
      <translation>Lookmark ブラウザー</translation>
    </message>
    <message>
      <source>TTL_LOOKMARK_INSPECTOR</source>
      <translation>Lookmark インスペクター</translation>
    </message>
    <message>
      <source>TTL_COMPARATIVE_VIEW_INSPECTOR</source>
      <translation>比較検査</translation>
    </message>
    <message>
      <source>TTL_ANIMATION_VIEW</source>
      <translation>アニメーション ビュー</translation>
    </message>
    <message>
      <source>TTL_SELECTION_INSPECTOR</source>
      <translation>選択部インスペクター</translation>
    </message>
    <message>
      <source>TTL_COLLABORATIVE_DOCK</source>
      <translation>コラボレーション パネル</translation>
    </message>
    <message>
      <source>TTL_MEMORY_INSPECTOR</source>
      <translation>メモリ検査</translation>
    </message>
    <message>
      <source>TOP_OPEN_FILE</source>
      <translation>Paraview のファイルを開く</translation>
    </message>
    <message>
      <source>MEN_OPEN</source>
      <translation>&amp; インポート.</translation>
    </message>
    <message>
      <source>MEN_OPEN_FILE</source>
      <translation>ParaView のファイルを開く.</translation>
    </message>
    <message>
      <source>STB_OPEN_FILE</source>
      <translation>Paraview のファイルを開く</translation>
    </message>
    <message>
      <source>MEN_RECENT_FILES</source>
      <translation>最近の ParaView ファイル</translation>
    </message>
    <message>
      <source>TOP_LOAD_STATE</source>
      <translation>読み込み状態</translation>
    </message>
    <message>
      <source>MEN_LOAD_STATE</source>
      <translation>&amp; 負荷状態.</translation>
    </message>
    <message>
      <source>STB_LOAD_STATE</source>
      <translation>読み込み状態</translation>
    </message>
    <message>
      <source>TOP_SAVE_STATE</source>
      <translation>状態を保存します。</translation>
    </message>
    <message>
      <source>MEN_SAVE_STATE</source>
      <translation>&amp; の状態を保存.</translation>
    </message>
    <message>
      <source>STB_SAVE_STATE</source>
      <translation>状態を保存します。</translation>
    </message>
    <message>
      <source>TOP_SAVE_DATA</source>
      <translation>データを保存します。</translation>
    </message>
    <message>
      <source>MEN_SAVE_DATA</source>
      <translation>データを保存.</translation>
    </message>
    <message>
      <source>STB_SAVE_DATA</source>
      <translation>データを保存します。</translation>
    </message>
    <message>
      <source>TOP_SAVE_SCREENSHOT</source>
      <translation>スクリーン ショットを保存します。</translation>
    </message>
    <message>
      <source>MEN_SAVE_SCREENSHOT</source>
      <translation>スクリーン ショットを保存.</translation>
    </message>
    <message>
      <source>STB_SAVE_SCREENSHOT</source>
      <translation>スクリーン ショットを保存します。</translation>
    </message>
    <message>
      <source>TOP_EXPORT</source>
      <translation>エクスポート</translation>
    </message>
    <message>
      <source>MEN_EXPORT</source>
      <translation>エクスポート.</translation>
    </message>
    <message>
      <source>STB_EXPORT</source>
      <translation>エクスポート</translation>
    </message>
    <message>
      <source>TOP_SAVE_ANIMATION</source>
      <translation>アニメーションを保存します。</translation>
    </message>
    <message>
      <source>MEN_SAVE_ANIMATION</source>
      <translation>保存アニメーション. &amp;</translation>
    </message>
    <message>
      <source>STB_SAVE_ANIMATION</source>
      <translation>アニメーションを保存します。</translation>
    </message>
    <message>
      <source>TOP_SAVE_GEOMETRY</source>
      <translation>ジオメトリを保存します。</translation>
    </message>
    <message>
      <source>MEN_SAVE_GEOMETRY</source>
      <translation>保存 &amp; 幾何学.</translation>
    </message>
    <message>
      <source>STB_SAVE_GEOMETRY</source>
      <translation>ジオメトリを保存します。</translation>
    </message>
    <message>
      <source>TOP_CONNECT</source>
      <translation>接続</translation>
    </message>
    <message>
      <source>MEN_CONNECT</source>
      <translation>&amp; 接続.</translation>
    </message>
    <message>
      <source>STB_CONNECT</source>
      <translation>サーバーへの接続します。</translation>
    </message>
    <message>
      <source>TOP_DISCONNECT</source>
      <translation>切断</translation>
    </message>
    <message>
      <source>MEN_DISCONNECT</source>
      <translation>&amp; 切断</translation>
    </message>
    <message>
      <source>STB_DISCONNECT</source>
      <translation>サーバーから切断します。</translation>
    </message>
    <message>
      <source>TOP_UNDO</source>
      <translation>元に戻す</translation>
    </message>
    <message>
      <source>MEN_UNDO</source>
      <translation>&amp; 元に戻す</translation>
    </message>
    <message>
      <source>MEN_CANTUNDO</source>
      <translation>元に戻すことはできません。</translation>
    </message>
    <message>
      <source>MEN_UNDO_ACTION</source>
      <translation>&amp; 元に戻す%1</translation>
    </message>
    <message>
      <source>MEN_UNDO_ACTION_TIP</source>
      <translation>%1 を元に戻す</translation>
    </message>
    <message>
      <source>STB_UNDO</source>
      <translation>最後の操作を元に戻します</translation>
    </message>
    <message>
      <source>INF_APP_UNDOACTIONS</source>
      <translation>%1 アクションを元に戻します</translation>
    </message>
    <message>
      <source>TOP_REDO</source>
      <translation>やり直し</translation>
    </message>
    <message>
      <source>MEN_REDO</source>
      <translation>&amp; やり直し</translation>
    </message>
    <message>
      <source>MEN_CANTREDO</source>
      <translation>やり直しできません。</translation>
    </message>
    <message>
      <source>MEN_REDO_ACTION</source>
      <translation>&amp; Redo%1</translation>
    </message>
    <message>
      <source>MEN_REDO_ACTION_TIP</source>
      <translation>%1 をやり直し</translation>
    </message>
    <message>
      <source>STB_REDO</source>
      <translation>最後の操作をやり直します</translation>
    </message>
    <message>
      <source>INF_APP_REDOACTIONS</source>
      <translation>%1 アクションをやり直します</translation>
    </message>
    <message>
      <source>TOP_CAMERA_UNDO</source>
      <translation>カメラの元に戻す</translation>
    </message>
    <message>
      <source>MEN_CAMERA_UNDO</source>
      <translation>カメラの元に戻す</translation>
    </message>
    <message>
      <source>MEN_CANT_CAMERA_UNDO</source>
      <translation>カメラを元に戻すことはできません。</translation>
    </message>
    <message>
      <source>MEN_CAMERA_UNDO_ACTION</source>
      <translation>U &amp; ndo%1</translation>
    </message>
    <message>
      <source>MEN_CAMERA_UNDO_ACTION_TIP</source>
      <translation>%1 を元に戻す</translation>
    </message>
    <message>
      <source>STB_CAMERA_UNDO</source>
      <translation>最後のカメラの操作を元に戻します</translation>
    </message>
    <message>
      <source>INF_APP_CAMERA_UNDOACTIONS</source>
      <translation>%1 カメラ アクションを元に戻します</translation>
    </message>
    <message>
      <source>TOP_CAMERA_REDO</source>
      <translation>カメラのやり直し</translation>
    </message>
    <message>
      <source>MEN_CAMERA_REDO</source>
      <translation>カメラのやり直し</translation>
    </message>
    <message>
      <source>MEN_CANT_CAMERA_REDO</source>
      <translation>カメラをやり直すことはできません。</translation>
    </message>
    <message>
      <source>MEN_CAMERA_REDO_ACTION</source>
      <translation>R &amp; 江戸%1</translation>
    </message>
    <message>
      <source>MEN_CAMERA_REDO_ACTION_TIP</source>
      <translation>%1 をやり直し</translation>
    </message>
    <message>
      <source>STB_CAMERA_REDO</source>
      <translation>最後のカメラの操作をやり直します</translation>
    </message>
    <message>
      <source>INF_APP_CAMERA_REDOACTIONS</source>
      <translation>%1 カメラ アクションをやり直します</translation>
    </message>
    <message>
      <source>TOP_CHANGE_INPUT</source>
      <translation>変更の入力.</translation>
    </message>
    <message>
      <source>MEN_FIND_DATA</source>
      <translation>データを見つける.</translation>
    </message>
    <message>
      <source>MEN_CHANGE_INPUT</source>
      <translation>変更 &amp; の入力.</translation>
    </message>
    <message>
      <source>STB_CHANGE_INPUT</source>
      <translation>入力フィルターを変更します。</translation>
    </message>
    <message>
      <source>INF_APP_CHANGE_INPUTACTIONS</source>
      <translation>入力フィルターを変更します。</translation>
    </message>
    <message>
      <source>MEN_IGNORE_TIME</source>
      <translation>時間を無視します。</translation>
    </message>
    <message>
      <source>TOP_IGNORE_TIME</source>
      <translation>時間を無視します。</translation>
    </message>
    <message>
      <source>STB_IGNORE_TIME</source>
      <translation>アニメーションからのこのソース/フィルターの時間を無視します。</translation>
    </message>
    <message>
      <source>TOP_DELETE</source>
      <translation>削除</translation>
    </message>
    <message>
      <source>MEN_DELETE</source>
      <translation>&amp; 削除</translation>
    </message>
    <message>
      <source>STB_DELETE</source>
      <translation>削除</translation>
    </message>
    <message>
      <source>TOP_DELETE_ALL</source>
      <translation>すべて削除します。</translation>
    </message>
    <message>
      <source>MEN_DELETE_ALL</source>
      <translation>すべて削除します。</translation>
    </message>
    <message>
      <source>STB_DELETE_ALL</source>
      <translation>すべて削除します。</translation>
    </message>
    <message>
      <source>TOP_INTERACT</source>
      <translation>対話</translation>
    </message>
    <message>
      <source>MEN_INTERACT</source>
      <translation>対話</translation>
    </message>
    <message>
      <source>STB_INTERACT</source>
      <translation>対話</translation>
    </message>
    <message>
      <source>TOP_SELECT_CELLS_ON</source>
      <translation>セルを選択します</translation>
    </message>
    <message>
      <source>MEN_SELECT_CELLS_ON</source>
      <translation>セルを選択します</translation>
    </message>
    <message>
      <source>STB_SELECT_CELLS_ON</source>
      <translation>セルを選択します</translation>
    </message>
    <message>
      <source>TOP_SELECT_POINTS_ON</source>
      <translation>選択ポイント</translation>
    </message>
    <message>
      <source>MEN_SELECT_POINTS_ON</source>
      <translation>選択ポイント</translation>
    </message>
    <message>
      <source>STB_SELECT_POINTS_ON</source>
      <translation>選択ポイント</translation>
    </message>
    <message>
      <source>TOP_SELECT_CELLS_THROUGH</source>
      <translation>セルを選択します</translation>
    </message>
    <message>
      <source>MEN_SELECT_CELLS_THROUGH</source>
      <translation>セルを選択します</translation>
    </message>
    <message>
      <source>STB_SELECT_CELLS_THROUGH</source>
      <translation>セルを選択します</translation>
    </message>
    <message>
      <source>TOP_SELECT_POINTS_THROUGH</source>
      <translation>選択点</translation>
    </message>
    <message>
      <source>MEN_SELECT_POINTS_THROUGH</source>
      <translation>選択点</translation>
    </message>
    <message>
      <source>STB_SELECT_POINTS_THROUGH</source>
      <translation>選択点</translation>
    </message>
    <message>
      <source>TOP_SELECT_BLOCK</source>
      <translation>ブロックを選択します</translation>
    </message>
    <message>
      <source>MEN_SELECT_BLOCK</source>
      <translation>ブロックを選択します</translation>
    </message>
    <message>
      <source>STB_SELECT_BLOCK</source>
      <translation>ブロックを選択します</translation>
    </message>
    <message>
      <source>TOP_SETTINGS</source>
      <translation>設定</translation>
    </message>
    <message>
      <source>MEN_SETTINGS</source>
      <translation>設定。。。</translation>
    </message>
    <message>
      <source>STB_SETTINGS</source>
      <translation>設定</translation>
    </message>
    <message>
      <source>TOP_VIEW_SETTINGS</source>
      <translation>ビューの設定</translation>
    </message>
    <message>
      <source>MEN_VIEW_SETTINGS</source>
      <translation>ビューの設定.</translation>
    </message>
    <message>
      <source>STB_VIEW_SETTINGS</source>
      <translation>ビューの設定</translation>
    </message>
    <message>
      <source>MEN_CAMERA</source>
      <translation>カメラ</translation>
    </message>
    <message>
      <source>TOP_RESET_CAMERA</source>
      <translation>カメラをリセットします。</translation>
    </message>
    <message>
      <source>MEN_RESET_CAMERA</source>
      <translation>&amp; リセット</translation>
    </message>
    <message>
      <source>STB_RESET_CAMERA</source>
      <translation>カメラをリセットします。</translation>
    </message>
    <message>
      <source>TOP_+X</source>
      <translation>ビューの方向を設定する + X</translation>
    </message>
    <message>
      <source>MEN_+X</source>
      <translation>+ X</translation>
    </message>
    <message>
      <source>STB_+X</source>
      <translation>ビューの方向を設定する + X</translation>
    </message>
    <message>
      <source>TOP_-X</source>
      <translation>表示方向を設定する -X</translation>
    </message>
    <message>
      <source>MEN_-X</source>
      <translation>-X</translation>
    </message>
    <message>
      <source>STB_-X</source>
      <translation>表示方向を設定する -X</translation>
    </message>
    <message>
      <source>TOP_+Y</source>
      <translation>セット ビュー方向に + Y</translation>
    </message>
    <message>
      <source>MEN_+Y</source>
      <translation>+ Y</translation>
    </message>
    <message>
      <source>STB_+Y</source>
      <translation>セット ビュー方向に + Y</translation>
    </message>
    <message>
      <source>TOP_-Y</source>
      <translation>Y - ビュー方向に設定します。</translation>
    </message>
    <message>
      <source>MEN_-Y</source>
      <translation>-Y</translation>
    </message>
    <message>
      <source>STB_-Y</source>
      <translation>Y - ビュー方向に設定します。</translation>
    </message>
    <message>
      <source>TOP_+Z</source>
      <translation>セット ビュー方向に + Z</translation>
    </message>
    <message>
      <source>MEN_+Z</source>
      <translation>+ Z</translation>
    </message>
    <message>
      <source>STB_+Z</source>
      <translation>セット ビュー方向に + Z</translation>
    </message>
    <message>
      <source>TOP_-Z</source>
      <translation>表示方向を設定する -Z に</translation>
    </message>
    <message>
      <source>MEN_-Z</source>
      <translation>-Z</translation>
    </message>
    <message>
      <source>STB_-Z</source>
      <translation>表示方向を設定する -Z に</translation>
    </message>
    <message>
      <source>TOP_SHOW_CENTER</source>
      <translation>ショー センター</translation>
    </message>
    <message>
      <source>MEN_SHOW_CENTER</source>
      <translation>ショー センター</translation>
    </message>
    <message>
      <source>PRP_APP_SHOW_CENTER</source>
      <translation>回転の中心の表示/非表示</translation>
    </message>
    <message>
      <source>TOP_RESET_CENTER</source>
      <translation>リセット センター</translation>
    </message>
    <message>
      <source>MEN_RESET_CENTER</source>
      <translation>リセット センター</translation>
    </message>
    <message>
      <source>STB_RESET_CENTER</source>
      <translation>回転の中心をリセットします。</translation>
    </message>
    <message>
      <source>TOP_PICK_CENTER</source>
      <translation>ピックアップ センター</translation>
    </message>
    <message>
      <source>MEN_PICK_CENTER</source>
      <translation>ピックアップ センター</translation>
    </message>
    <message>
      <source>PRP_APP_PICK_CENTER</source>
      <translation>マウスを押して回転の中心を選択するには</translation>
    </message>
    <message>
      <source>TOP_SHOW_COLOR_LEGEND</source>
      <translation>色の凡例の表示の切り替え</translation>
    </message>
    <message>
      <source>MEN_SHOW_COLOR_LEGEND</source>
      <translation>色の凡例を表示します。</translation>
    </message>
    <message>
      <source>PRP_APP_SHOW_COLOR_LEGEND</source>
      <translation>色の凡例の表示の切り替え</translation>
    </message>
    <message>
      <source>TOP_EDIT_COLOR_MAP</source>
      <translation>カラー マップを編集します。</translation>
    </message>
    <message>
      <source>MEN_EDIT_COLOR_MAP</source>
      <translation>カラー マップを編集します。</translation>
    </message>
    <message>
      <source>PRP_APP_EDIT_COLOR_MAP</source>
      <translation>カラー マップを編集します。</translation>
    </message>
    <message>
      <source>TOP_RESET_RANGE</source>
      <translation>データ範囲のサイズを変更します。</translation>
    </message>
    <message>
      <source>MEN_RESET_RANGE</source>
      <translation>範囲のリセット</translation>
    </message>
    <message>
      <source>PRP_APP_RESET_RANGE</source>
      <translation>データ範囲のサイズを変更します。</translation>
    </message>
    <message>
      <source>MEN_DESK_SOURCES</source>
      <translation>&amp; ソース</translation>
    </message>
    <message>
      <source>MEN_DESK_FILTERS</source>
      <translation>F &amp; フィルター</translation>
    </message>
    <message>
      <source>MEN_DESK_ANIMATION</source>
      <translation>A &amp; nimation</translation>
    </message>
    <message>
      <source>TOP_FIRST_FRAME</source>
      <translation>最初のフレーム</translation>
    </message>
    <message>
      <source>MEN_FIRST_FRAME</source>
      <translation>&amp; 最初のフレーム</translation>
    </message>
    <message>
      <source>STB_FIRST_FRAME</source>
      <translation>最初のフレーム</translation>
    </message>
    <message>
      <source>TOP_PREVIOUS_FRAME</source>
      <translation>前のフレーム</translation>
    </message>
    <message>
      <source>MEN_PREVIOUS_FRAME</source>
      <translation>前 &amp; 箇所フレーム</translation>
    </message>
    <message>
      <source>STB_PREVIOUS_FRAME</source>
      <translation>前のフレーム</translation>
    </message>
    <message>
      <source>TOP_PLAY</source>
      <translation>再生</translation>
    </message>
    <message>
      <source>MEN_PLAY</source>
      <translation>&amp; プレイ</translation>
    </message>
    <message>
      <source>STB_PLAY</source>
      <translation>再生</translation>
    </message>
    <message>
      <source>TOP_NEXT_FRAME</source>
      <translation>次のフレーム</translation>
    </message>
    <message>
      <source>MEN_NEXT_FRAME</source>
      <translation>&amp; 次のフレーム</translation>
    </message>
    <message>
      <source>STB_NEXT_FRAME</source>
      <translation>次のフレーム</translation>
    </message>
    <message>
      <source>TOP_LAST_FRAME</source>
      <translation>最後のフレーム</translation>
    </message>
    <message>
      <source>MEN_LAST_FRAME</source>
      <translation>&amp; 最後のフレーム</translation>
    </message>
    <message>
      <source>STB_LAST_FRAME</source>
      <translation>最後のフレーム</translation>
    </message>
    <message>
      <source>TOP_LOOP</source>
      <translation>ループ</translation>
    </message>
    <message>
      <source>MEN_LOOP</source>
      <translation>L &amp; オブジェクト指向</translation>
    </message>
    <message>
      <source>PRP_APP_LOOP</source>
      <translation>ループ</translation>
    </message>
    <message>
      <source>MEN_DESK_TOOLS</source>
      <translation>&amp; ツール</translation>
    </message>
    <message>
      <source>TOP_CREATE_CUSTOM_FILTER</source>
      <translation>カスタム フィルターを作成します。</translation>
    </message>
    <message>
      <source>MEN_CREATE_CUSTOM_FILTER</source>
      <translation>&amp; カスタム フィルターを作成する.</translation>
    </message>
    <message>
      <source>STB_CREATE_CUSTOM_FILTER</source>
      <translation>カスタム フィルターを作成します。</translation>
    </message>
    <message>
      <source>TOP_MANAGE_CUSTOM_FILTERS</source>
      <translation>カスタム フィルターを管理します。</translation>
    </message>
    <message>
      <source>MEN_MANAGE_CUSTOM_FILTERS</source>
      <translation>&amp; カスタム フィルターを管理する.</translation>
    </message>
    <message>
      <source>STB_MANAGE_CUSTOM_FILTERS</source>
      <translation>カスタム フィルターを管理します。</translation>
    </message>
    <message>
      <source>TOP_CREATE_LOOKMARK</source>
      <translation>Lookmark を作成します。</translation>
    </message>
    <message>
      <source>MEN_CREATE_LOOKMARK</source>
      <translation>Lookmark を作成します。</translation>
    </message>
    <message>
      <source>STB_CREATE_LOOKMARK</source>
      <translation>Lookmark を作成します。</translation>
    </message>
    <message>
      <source>TOP_MANAGE_LINKS</source>
      <translation>リンクを管理します。</translation>
    </message>
    <message>
      <source>MEN_MANAGE_LINKS</source>
      <translation>リンクの管理.</translation>
    </message>
    <message>
      <source>STB_MANAGE_LINKS</source>
      <translation>リンクを管理します。</translation>
    </message>
    <message>
      <source>TOP_ADD_CAMERA_LINK</source>
      <translation>カメラのリンクを追加します。</translation>
    </message>
    <message>
      <source>MEN_ADD_CAMERA_LINK</source>
      <translation>カメラ リンクの追加.</translation>
    </message>
    <message>
      <source>STB_ADD_CAMERA_LINK</source>
      <translation>カメラのリンクを追加します。</translation>
    </message>
    <message>
      <source>WRN_ADD_CAMERA_LINK</source>
      <translation>カメラのリンクを追加： レンダリング モジュール アクティブでないです。</translation>
    </message>
    <message>
      <source>TOP_MANAGE_PLUGINS</source>
      <translation>プラグイン/拡張機能を管理します。</translation>
    </message>
    <message>
      <source>MEN_MANAGE_PLUGINS</source>
      <translation>プラグインの管理.</translation>
    </message>
    <message>
      <source>STB_MANAGE_PLUGINS</source>
      <translation>プラグイン/拡張機能を管理します。</translation>
    </message>
    <message>
      <source>TOP_DUMP_WIDGET_NAMES</source>
      <translation>ウィジェット名をダンプします。</translation>
    </message>
    <message>
      <source>MEN_DUMP_WIDGET_NAMES</source>
      <translation>&amp; ウィジェット名をダンプ</translation>
    </message>
    <message>
      <source>STB_DUMP_WIDGET_NAMES</source>
      <translation>ウィジェット名をダンプします。</translation>
    </message>
    <message>
      <source>TOP_RECORD_TEST</source>
      <translation>レコードのテスト</translation>
    </message>
    <message>
      <source>MEN_RECORD_TEST</source>
      <translation>&amp; レコードのテスト</translation>
    </message>
    <message>
      <source>STB_RECORD_TEST</source>
      <translation>レコードのテスト</translation>
    </message>
    <message>
      <source>TOP_RECORD_TEST_SCREENSHOT</source>
      <translation>レコードのテストのスクリーン ショット</translation>
    </message>
    <message>
      <source>MEN_RECORD_TEST_SCREENSHOT</source>
      <translation>レコード &amp; テストのスクリーン ショット</translation>
    </message>
    <message>
      <source>STB_RECORD_TEST_SCREENSHOT</source>
      <translation>レコードのテストのスクリーン ショット</translation>
    </message>
    <message>
      <source>TOP_PLAY_TEST</source>
      <translation>再生テスト</translation>
    </message>
    <message>
      <source>MEN_PLAY_TEST</source>
      <translation>再生テスト</translation>
    </message>
    <message>
      <source>STB_PLAY_TEST</source>
      <translation>再生テスト</translation>
    </message>
    <message>
      <source>TOP_MAX_WINDOW_SIZE</source>
      <translation>ロック表示サイズ</translation>
    </message>
    <message>
      <source>MEN_MAX_WINDOW_SIZE</source>
      <translation>ロック表示サイズ</translation>
    </message>
    <message>
      <source>MEN_CUSTOM_WINDOW_SIZE</source>
      <translation>ロック表示サイズ カスタム.</translation>
    </message>
    <message>
      <source>PRP_APP_MAX_WINDOW_SIZE</source>
      <translation>ロック表示サイズ</translation>
    </message>
    <message>
      <source>TOP_TIMER_LOG</source>
      <translation>タイマー ログ</translation>
    </message>
    <message>
      <source>MEN_TIMER_LOG</source>
      <translation>タイマー &amp; ログ</translation>
    </message>
    <message>
      <source>STB_TIMER_LOG</source>
      <translation>タイマー ログ</translation>
    </message>
    <message>
      <source>TOP_OUTPUT_WINDOW</source>
      <translation>出力ウィンドウ</translation>
    </message>
    <message>
      <source>MEN_OUTPUT_WINDOW</source>
      <translation>&amp; 出力ウィンドウ</translation>
    </message>
    <message>
      <source>STB_OUTPUT_WINDOW</source>
      <translation>出力ウィンドウ</translation>
    </message>
    <message>
      <source>TOP_PYTHON_SHELL</source>
      <translation>Python シェル</translation>
    </message>
    <message>
      <source>MEN_PYTHON_SHELL</source>
      <translation>Python &amp; シェル</translation>
    </message>
    <message>
      <source>STB_PYTHON_SHELL</source>
      <translation>Python シェル</translation>
    </message>
    <message>
      <source>TOP_ABOUT</source>
      <translation>ParaView について</translation>
    </message>
    <message>
      <source>MEN_ABOUT</source>
      <translation>ParaView について.</translation>
    </message>
    <message>
      <source>MEN_PVHELP</source>
      <translation>ParaView のヘルプ</translation>
    </message>
    <message>
      <source>STB_ABOUT</source>
      <translation>ParaView について</translation>
    </message>
    <message>
      <source>TOP_PARAVIEW_HELP</source>
      <translation>ParaView のユーザー マニュアル</translation>
    </message>
    <message>
      <source>MEN_PARAVIEW_HELP</source>
      <translation>ParaView のヘルプ</translation>
    </message>
    <message>
      <source>STB_PARAVIEW_HELP</source>
      <translation>ParaView のユーザー マニュアルの参照</translation>
    </message>
    <message>
      <source>TOP_ENABLE_TOOLTIPS</source>
      <translation>ツールヒントを有効にします。</translation>
    </message>
    <message>
      <source>MEN_ENABLE_TOOLTIPS</source>
      <translation>ツールヒントを有効にします。</translation>
    </message>
    <message>
      <source>STB_ENABLE_TOOLTIPS</source>
      <translation>ツールヒントを有効にします。</translation>
    </message>
    <message>
      <source>STB_PREACCEPT</source>
      <translation>更新しています.</translation>
    </message>
    <message>
      <source>STB_POSTACCEPT</source>
      <translation>準備ができて</translation>
    </message>
    <message>
      <source>TOOL_ACTIVE_VARIABLE_CONTROLS</source>
      <translation>アクティブな変数をコントロール</translation>
    </message>
    <message>
      <source>TOOL_CAMERA_CONTROLS</source>
      <translation>カメラ コントロール</translation>
    </message>
    <message>
      <source>TOOL_CENTER_AXES_CONTROLS</source>
      <translation>軸コントロール センター</translation>
    </message>
    <message>
      <source>TOOL_COMMON_FILTERS</source>
      <translation>一般的なフィルター</translation>
    </message>
    <message>
      <source>TOOL_CURRENT_TIME_CONTROLS</source>
      <translation>現在の時間制御</translation>
    </message>
    <message>
      <source>TOOL_LOOKMARKS</source>
      <translation>Lookmarks</translation>
    </message>
    <message>
      <source>TOOL_MAIN_CONTROLS</source>
      <translation>メイン コントロールします。</translation>
    </message>
    <message>
      <source>TOOL_REPRESENTATION</source>
      <translation>表現</translation>
    </message>
    <message>
      <source>TOOL_SELECTION_CONTROLS</source>
      <translation>選択コントロール</translation>
    </message>
    <message>
      <source>TOOL_UNDOREDO_CONTROLS</source>
      <translation>コントロールのアンドゥ/リドゥ</translation>
    </message>
    <message>
      <source>TOOL_VCR_CONTROLS</source>
      <translation>VCR コントロール</translation>
    </message>
    <message>
      <source>PREF_STOP_TRACE</source>
      <translation>(の次のセッションのみ) トレースを非アクティブ化します。</translation>
    </message>
    <message>
      <source>PREF_SHOW_COLOR_LEGEND</source>
      <translation>色の凡例を表示します。</translation>
    </message>
    <message>
      <source>TIT_PVISSETTINGS</source>
      <translation>ParaVis の設定</translation>
    </message>
    <message>
      <source>TIT_PVIEWSETTINGS</source>
      <translation>ParaView の設定</translation>
    </message>
    <message>
      <source>MEN_MACROS</source>
      <translation>&amp; マクロ</translation>
    </message>
    <message>
      <source>PREF_SAVE_TYPE_LBL</source>
      <translation>Paraview の状態タイプを保存</translation>
    </message>
    <message>
      <source>PREF_SAVE_TYPE_0</source>
      <translation>組み込みサーバーのみの参照ファイルを保存します。</translation>
    </message>
    <message>
      <source>PREF_SAVE_TYPE_1</source>
      <translation>アクセス可能な場合常に参照先のファイルを保存します。</translation>
    </message>
    <message>
      <source>PREF_SAVE_TYPE_2</source>
      <translation>参照先のファイルを保存しないで</translation>
    </message>
    <message>
      <source>MEN_NEW_PV_VIEW</source>
      <translation>ParaView ビュー</translation>
    </message>
    <message>
      <source>MEN_SAVE_MULTI_STATE</source>
      <translation>状態を保存します。</translation>
    </message>
    <message>
      <source>MEN_ADD_STATE</source>
      <translation>状態を追加します。</translation>
    </message>
    <message>
      <source>MEN_CLEAN_ADD_STATE</source>
      <translation>きれいにし、状態を追加</translation>
    </message>
    <message>
      <source>MEN_PARAVIS_RENAME</source>
      <translation>名前の変更</translation>
    </message>
    <message>
      <source>MEN_PARAVIS_DELETE</source>
      <translation>削除</translation>
    </message>
    <message>
      <source>SAVED_PARAVIEW_STATE_NAME</source>
      <translation>Paraview の状態:</translation>
    </message>
    <message>
      <source>ERR_ERROR</source>
      <translation>エラー</translation>
    </message>
    <message>
      <source>ERR_STATE_CANNOT_BE_RESTORED</source>
      <translation>状態を復元することはできません。</translation>
    </message>
  </context>
</TS>
